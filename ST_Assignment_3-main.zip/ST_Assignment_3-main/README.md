# CI/CD Pipeline Assignment

Roll Number: 21L-1768

This repository contains the solution for the CI/CD pipeline assignment.
